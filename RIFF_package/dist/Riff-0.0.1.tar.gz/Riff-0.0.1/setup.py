import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="Riff", # Replace with your own username
    version="0.0.1",
    author="Chuyao Wang",
    author_email="wcy22@mails.jlu.edu.cn",
    description="Pseudo-label supervised graph neural network for robust, fine-grained, interpretable spatial domain identification",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/DDDoGGie/RIFF",
    packages=setuptools.find_packages(),
    install_requires=["torch","dgl", "pandas","numpy","scipy","scanpy","anndata","louvain","scikit-learn"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)